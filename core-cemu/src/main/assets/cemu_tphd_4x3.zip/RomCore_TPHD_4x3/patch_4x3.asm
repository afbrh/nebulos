[TPHDv81]
moduleMatches = 0x1A03E108

#rodata constants
0x1005AAD8 = .float $aspectRatio
_aspectAddr = 0x1006AAD8

#code changes
0x028D75B8 = lis r11, _aspectAddr@h
0x028D75C0 = lfs f0, _aspectAddr@l(r11) ; Main 3d Aspect
0x029BB184 = lis r12, _aspectAddr@h
0x029BB188 = lfs f2, _aspectAddr@l(r12) ; may just be the intro zelda graphic

# 4:3 UI space: the game's logical layout table (0x100A4CE4: {w,h} u16 pairs, index = wide flag) is 808x448 for wide.
# Make it 808x597 (4:3 shape) so the ortho the UI is drawn with is isotropic on a 4:3 screen.
0x100A4CEA = .short 597

# Vertical edge hugging. The UI is laid out for 448 rows but the ortho is now 597 rows tall, so without this it sits in a centred block.
# J2DPane::draw (0x02B34334) already does this horizontally: a root pane (J2DScreen) is stretched to the ortho width (x scale and offset
# about 304) and 'n_43' nodes are un-stretched again, so element positions follow the screen edges while their shapes stay put.
#  uiHookB / uiHookBR : same for y on the root pane (scale y and offset about 224 by ortho height / 448; restored after drawing).
#  uiHookR            : after a pane's global matrix is built, a picture/window below an 'n_43' node is un-stretched in y
#                       (rows scaled by 448 / ortho height); panes taller than 120 (dim overlays, frames) stay stretched.
0x02B3456C = bl uiHookR
0x02B346C4 = bl uiHookB
0x02B34754 = bl uiHookBR

.origin = codecave

uiHookR:
stfs f27, 0x58(r27)
mflr r0
stwu r1, -0x20(r1)
stw r0, 0x24(r1)
lwz r12, 0xf4(r27)
lwz r12, 0x14(r12)
mtctr r12
mr r3, r27
bctrl
addi r3, r3, -0x11
cmplwi r3, 1
bgt uiOut
lwz r8, 0xb8(r28)
lwz r9, 0x3c(r8)
mtctr r9
mr r3, r28
bctrl
cmpwi r3, 1
bne uiOut
mr r5, r31
lis r8, 0x6e5f
ori r8, r8, 0x3433
uiWalk:
cmpwi r5, 0
beq uiOut
lwz r6, 0x10(r5)
lwz r7, 0x14(r5)
xor r7, r7, r8
or. r7, r7, r6
beq uiYes
lwz r9, 0xe4(r5)
li r5, 0
cmpwi r9, 0
beq uiOut
lwz r5, 0xc(r9)
b uiWalk
uiYes:
lis r12, uiC@ha
addi r12, r12, uiC@l
lfs f0, 0x24(r27)
lfs f1, 0x1c(r27)
fsubs f0, f0, f1
lfs f1, 0x30(r12)
fcmpu cr0, f0, f1
bgt uiOut
lfs f0, 0xc0(r28)
lfs f1, 0xc8(r28)
fsubs f1, f1, f0
lfs f2, 0(r12)
fdivs f2, f2, f1
lfs f3, 0x88(r27)
lfs f4, 0x8c(r27)
lfs f5, 0x90(r27)
fmuls f3, f3, f2
fmuls f4, f4, f2
fmuls f5, f5, f2
stfs f3, 0x88(r27)
stfs f4, 0x8c(r27)
stfs f5, 0x90(r27)
uiOut:
lwz r0, 0x24(r1)
mtlr r0
addi r1, r1, 0x20
blr

uiHookB:
stfs f9, 0xcc(r27)
lfs f1, 0xc0(r28)
lfs f2, 0xc8(r28)
fsubs f2, f2, f1
lis r12, uiC@ha
addi r12, r12, uiC@l
lfs f3, 0(r12)
fdivs f4, f2, f3
lfs f5, 0xc8(r27)
lfs f6, 0xd0(r27)
stfs f5, 0x24(r12)
stfs f6, 0x28(r12)
li r0, 1
stw r0, 0x20(r12)
lfs f7, 4(r12)
fmuls f5, f5, f4
fsubs f6, f6, f7
fmadds f6, f6, f4, f7
stfs f5, 0xc8(r27)
stfs f6, 0xd0(r27)
blr

uiHookBR:
stfs f27, 0xc4(r27)
lis r12, uiC@ha
addi r12, r12, uiC@l
lwz r0, 0x20(r12)
cmpwi r0, 0
beqlr
li r0, 0
stw r0, 0x20(r12)
lfs f0, 0x24(r12)
stfs f0, 0xc8(r27)
lfs f0, 0x28(r12)
stfs f0, 0xd0(r27)
blr

# data: 0x00 448.0, 0x04 224.0, 0x20 root-saved flag, 0x24/0x28 saved scaleY/translateY, 0x30 max un-stretched pane height
uiC:
.float 448.0
.float 224.0
.int 0
.int 0
.int 0
.int 0
.int 0
.int 0
.int 0
.float 0.0
.float 0.0
.int 0
.float 120.0
